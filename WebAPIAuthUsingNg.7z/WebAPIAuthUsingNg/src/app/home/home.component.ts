import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserServiceService } from '../shared/user-service.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  userClaims: any;

  constructor(private router: Router, private userService: UserServiceService) { }

  ngOnInit() {
    debugger;
    this.userService.getUserClaims().subscribe((data: any) => {
      this.userClaims = data;
 
    });
  }
  Logout() {
    localStorage.removeItem('userToken');
    this.router.navigate(['/login']);
  }
 
}